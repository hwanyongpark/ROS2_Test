#include "rclcpp/rclcpp.hpp"
#include "multi_agent_comm/msg/agent_message.hpp"
#include <random>

using std::placeholders::_1;

class AgentNode : public rclcpp::Node {
public:
    AgentNode(int agent_id)
    : Node("agent_" + std::to_string(agent_id)), agent_id_(agent_id) {
        publisher_ = this->create_publisher<multi_agent_comm::msg::AgentMessage>("communication_test", 10);
        subscriber_ = this->create_subscription<multi_agent_comm::msg::AgentMessage>(
            "communication_test", 10, std::bind(&AgentNode::topic_callback, this, _1));

        auto timer_callback = [this]() -> void {
            auto message = multi_agent_comm::msg::AgentMessage();
            message.agent_id = this->agent_id_;
            message.status = "publishing done";
            message.timestamp = this->get_clock()->now();

            //RCLCPP_INFO(this->get_logger(), "Publishing: '%d, %s, %u'", message.agent_id, message.status.c_str(), message.timestamp.nanosec);  // Changed %ld to %u
            publisher_->publish(message);
        };

        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0.33, 1.0);  // 1~3Hz
        
        timer_ = this->create_wall_timer(std::chrono::milliseconds(int(1000 * dis(gen))), timer_callback);
    }

private:
    void topic_callback(const multi_agent_comm::msg::AgentMessage::SharedPtr msg) const {
        RCLCPP_INFO(this->get_logger(), "Heard: '%d, %s, %u'", msg->agent_id, msg->status.c_str(), msg->timestamp.nanosec);  // Changed %ld to %u
    }

    rclcpp::Publisher<multi_agent_comm::msg::AgentMessage>::SharedPtr publisher_;
    rclcpp::Subscription<multi_agent_comm::msg::AgentMessage>::SharedPtr subscriber_;
    rclcpp::TimerBase::SharedPtr timer_;
    int agent_id_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    if (argc != 2) {
        RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "usage: agent_node <agent_id>");
        return 1;
    }
    int agent_id = std::stoi(argv[1]);
    rclcpp::spin(std::make_shared<AgentNode>(agent_id));
    rclcpp::shutdown();
    return 0;
}